import java.awt.*; 
import javax.swing.*;  
import java.awt.event.*; 
import java.sql.*;
public class loginProject implements ActionListener{  
    static JButton button ; 
    public Statement stmt;
    JTextField usertext,address1,email1;
    JPasswordField userpass ;
    JTextField number;

   loginProject() {  
    JFrame frame = new JFrame();
    JPanel panel = new JPanel();  
    panel.setLayout(new GridLayout(6,5));  
    // JLabel label = new JLabel("Login Page"); 
    JLabel user = new JLabel("UserName"); 
    user.setForeground(Color.RED);
   
    JLabel password = new JLabel("Password");
    password.setForeground(Color.RED);
    JLabel no = new JLabel("Phone"); 
    no.setForeground(Color.RED);
    JLabel address = new JLabel("Address");
    address.setForeground(Color.RED);
    JLabel email = new JLabel("Email");
    email.setForeground(Color.RED);
    usertext = new JTextField(10);
    number = new JTextField(10);
    address1 = new JTextField(100);
    email1 = new JTextField(50);
    userpass = new JPasswordField(10);
    button = new JButton("SIGNUP");
    button.setBackground(Color.YELLOW);
    button.setForeground(Color.BLACK);

    button.addActionListener(this);

    panel.add(user);
    panel.add(usertext);
    panel.add(password); 
    panel.add(userpass); 
    panel.add(no); 
    panel.add(number);
    panel.add(email);
    panel.add(email1);
    panel.add(address);
    panel.add(address1);
    panel.add(button);  
    frame.getContentPane().add(panel);  

    user.setFont(new Font("Verdana", Font.BOLD, 20));
    password.setFont(new Font("Verdana", Font.BOLD, 20));
    usertext.setFont(new Font("Verdana", Font.BOLD, 20));
    userpass.setFont(new Font("Verdana", Font.BOLD, 20));
     button.setFont(new Font("Verdana", Font.BOLD, 20));
     email.setFont(new Font("Verdana", Font.BOLD, 20));
     email1.setFont(new Font("Verdana", Font.BOLD, 20));
     address.setFont(new Font("Verdana", Font.BOLD, 20));
     address1.setFont(new Font("Verdana", Font.BOLD, 20));
     number.setFont(new Font("Verdana", Font.BOLD, 20));
     no.setFont(new Font("Verdana", Font.BOLD, 20));
    
    frame.setLocationRelativeTo(null);  
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
    frame.setResizable(false);
    frame.setSize(588,508); 
    frame.setVisible(true);  
    frame.setTitle("SIGNIN PAGE");
    
    }
    public void actionPerformed(ActionEvent ev)
     {
         if(ev.getSource() == button)
         {
             String user ,pass,add,email ;
             user = usertext.getText();
             add = address1.getText();
             email = email1.getText();
             
             pass = new String(userpass.getPassword());
             int phone = Integer.parseInt(number.getText());
             try{
               
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/lol","root","");
            System.out.println("connection created");
            Statement stmt = con.createStatement();
            String st = "INSERT INTO login VALUES ('"+user+"' , '"+pass+"','"+phone+"','"+email+"','"+add+"')";
            stmt.executeUpdate(st);
            System.out.print("the data is inserted");
            stmt.close();
            con.close();
        }
        catch(Exception e)
        {
            System.out.print(e);
        }
        }
} 
}