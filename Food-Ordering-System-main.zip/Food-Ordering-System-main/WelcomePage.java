import java.awt.*;
import javax.swing.*; 
import java.awt.event.*; 
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.border.LineBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.MatteBorder;
// import java.awt.Graphics;
public class WelcomePage implements ActionListener{
    
   static JButton login ;
   static JButton signup ;
      public static void main (String a[])
   {
    JFrame frame = new JFrame("FOOD ORDERING SYSTEM");
    JPanel panel = new JPanel();
    JLabel lblWelcomeToFood = new JLabel("   WELCOME TO  FOOD ORDERING SYSTEM");
    lblWelcomeToFood.setBorder(new EtchedBorder(EtchedBorder.RAISED, Color.BLACK, Color.BLACK));
    lblWelcomeToFood.setBounds(0, 10, 779, 38);
    lblWelcomeToFood.setForeground(Color.RED);
    Image img = Toolkit.getDefaultToolkit().getImage("bgImage.jpg");
    panel.setLayout(null);

    panel.add(lblWelcomeToFood);
    frame.getContentPane().add(panel);
    // panel.add(img);
    lblWelcomeToFood.setFont(new Font("Arial Black", Font.BOLD, 30));
    login = new JButton("LOGIN");
    login.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
    login.setBounds(46, 247, 107, 38);
    panel.add(login);
    login.setBackground(Color.RED);
    login.addActionListener(new WelcomePage());
    login.setFont(new Font("Verdana", Font.BOLD,20));
    signup = new JButton("SIGNUP");
    signup.setBounds(43, 312, 128, 45);
    panel.add(signup);
    signup.setBackground(Color.RED);
    signup.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
    signup.addActionListener(new WelcomePage());
    signup.setFont(new Font("Verdana", Font.BOLD,20));
    
    JLabel lblNewLabel = new JLabel("New label");
    lblNewLabel.setBorder(new LineBorder(new Color(0, 0, 0)));
    lblNewLabel.setForeground(Color.WHITE);
    lblNewLabel.setIcon(new ImageIcon("C:\\Users\\MAYURESH\\Downloads\\pexels-eric-montanah-1342641 (1).jpg"));
    lblNewLabel.setBounds(0, 0, 779, 540);
    panel.add(lblNewLabel);
    frame.setLocationRelativeTo(null); 
    frame.setResizable(false); 
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(793,577); 
    frame.setVisible(true);
    }
    // public void paintComponent(Graphics g) {
    //     super.paintComponent(g);
    //     g.drawImage(img, 0, 0, null);
    //  }
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == signup)
        {
             new loginProject();   
        }   
        if(e.getSource() == login)
        {
            new MainLogin();
        }        
    }
}